export enum Schooling {
  primarySchool = 1,
  highShcool = 2,
  college = 3,
}
