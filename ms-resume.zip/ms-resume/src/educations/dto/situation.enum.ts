export enum Situation {
  stoped = 1,
  completed = 2,
  inProgress = 3,
}
