export interface IResumes {
    idList: string[]
}

export interface IResume {
    id: string
}