export enum Fluency {
  allOptions = 1,
  writing = 2,
  reading = 3,
  conversation = 4,
  writingAndReading = 5,
  writingAndConversation = 6
}
