export enum Seniority {
  junior = 1,
  full = 2,
  senior = 3,
}
