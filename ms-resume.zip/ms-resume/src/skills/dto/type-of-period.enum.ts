export enum TypeOfPeriod{
    month =1,
    year = 2
}