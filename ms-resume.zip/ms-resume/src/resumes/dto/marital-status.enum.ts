export enum MaritalStatus {
  single = 1,
  married = 2,
  separated = 3,
  divorced = 4,
  widowed = 5,
}
