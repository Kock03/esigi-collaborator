export enum GenderTypes {
  male = 1,
  female = 2,
  undefined = 3,
}
